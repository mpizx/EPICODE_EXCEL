/* Procediamo con la creazione delle tabelle e visto che le tabelle sono in inglese, manterrò le colonne in inglese. */
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50) NOT NULL,
    Category VARCHAR(50) NOT NULL
);

CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50) NOT NULL
);

CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT NOT NULL,
    RegionID INT NOT NULL,
    SalesDate DATE NOT NULL,
    Amount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID) ON DELETE CASCADE,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID) ON DELETE CASCADE
);

/* Popoliamo la tabella Product */
INSERT INTO Product (ProductID, ProductName, Category) VALUES
(1, 'Toy Car', 'Vehicles'),
(2, 'Doll', 'Figures'),
(3, 'Puzzle', 'Games'),
(4, 'Building Blocks', 'Construction');

/* Popoliamo la tabella Region */
INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'North America'),
(2, 'Europe'),
(3, 'Asia');

/* Popoliamo la tabella Sales */
INSERT INTO Sales (SalesID, ProductID, RegionID, SalesDate, Amount) VALUES
(1, 1, 1, '2023-01-15', 150.00),
(2, 2, 2, '2023-03-22', 200.00),
(3, 3, 3, '2023-07-30', 100.00),
(4, 1, 2, '2024-02-10', 300.00),
(5, 2, 3, '2024-04-05', 250.00);

/* 1. Verificare che i campi definiti come PK siano univoci.
NOTE: Verifichiamo che non ci siano duplicati nei campi ProductID, RegionID e SalesID, garantendo così l'unicità delle chiavi primarie.
Se nessun risultato viene restituito (NULL), significa che i campi definiti come chiavi primarie (ProductID, RegionID, SalesID) sono univoci in ciascuna tabella e confermando che non ci sono duplicati.*/
SELECT 
    ProductID
FROM
    Product
GROUP BY ProductID
HAVING COUNT(*) > 1;
SELECT 
    RegionID
FROM
    Region
GROUP BY RegionID
HAVING COUNT(*) > 1;
SELECT 
    SalesID
FROM
    Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

/* 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
NOTE: Con questa query andiamo ad elencare i prodotti che sono stati venduti almeno una volta e calcoliamo il fatturato totale per ciascun anno.*/
SELECT 
    p.ProductName,
    SUM(s.Amount) AS TotalRevenue,
    YEAR(s.SalesDate) AS Year
FROM
    Sales s
        JOIN
    Product p ON s.ProductID = p.ProductID
GROUP BY p.ProductName , YEAR(s.SalesDate);

/* 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
NOTE: Calcoliamo il fatturato totale per regione per ogni singolo anno, ordinando i risultati per anno e per fatturato in ordine decrescente.*/
SELECT 
    r.RegionName,
    SUM(s.Amount) AS TotalRevenue,
    YEAR(s.SalesDate) AS Year
FROM
    Sales s
        JOIN
    Region r ON s.RegionID = r.RegionID
GROUP BY r.RegionName , YEAR(s.SalesDate)
ORDER BY YEAR(s.SalesDate) , TotalRevenue DESC;

/* 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
NOTE: Determiniamo la categoria di articoli più venduta, ordinando le categorie in base al numero di vendite e limitando i risultati al primo elemento, visto che viene indicato di mostrare una sola categoria.*/
SELECT 
    p.Category, COUNT(s.SalesID) AS SalesCount
FROM
    Sales s
        JOIN
    Product p ON s.ProductID = p.ProductID
GROUP BY p.Category
ORDER BY SalesCount DESC
LIMIT 1;

/* 5.1 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
NOTE: Utilizziamo una sottoquery per trovare i ProductID che non sono presenti nella tabella Sales.*/
SELECT 
    p.ProductName
FROM
    Product p
WHERE
    p.ProductID NOT IN (SELECT DISTINCT
            ProductID
        FROM
            Sales);

/* 5.2 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
NOTE: Utilizziamo una LEFT JOIN per trovare i prodotti che non hanno corrispondenze nella tabella Sales.*/
SELECT 
    p.ProductName
FROM
    Product p
        LEFT JOIN
    Sales s ON p.ProductID = s.ProductID
WHERE
    s.SalesID IS NULL;

/* 6. Esporre l'elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). 
NOTE: Elenchiamo i prodotti con la data della loro ultima vendita.*/
SELECT 
    p.ProductName, MAX(s.SalesDate) AS LastSaleDate
FROM
    Sales s
        JOIN
    Product p ON s.ProductID = p.ProductID
GROUP BY p.ProductName
ORDER BY LastSaleDate DESC;